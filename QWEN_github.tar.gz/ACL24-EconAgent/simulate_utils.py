import sys
import numpy as np
import matplotlib.pyplot as plt
import yaml
import pandas as pd
import seaborn as sns
import re
import os
import multiprocessing
import scipy

save_path = './'

brackets = list(np.array([0, 97, 394.75, 842, 1607.25, 2041, 5103])*100/12)
quantiles = [0, 0.25, 0.5, 0.75, 1.0]

from datetime import datetime
world_start_time = datetime.strptime('2001.01', '%Y.%m')

prompt_cost_1k, completion_cost_1k = 0.001, 0.002

def prettify_document(document: str) -> str:
    # Remove sequences of whitespace characters (including newlines)
    cleaned = re.sub(r'\s+', ' ', document).strip()
    return cleaned


def get_multiple_completion(dialogs, num_cpus=15, temperature=0, max_tokens=100):
    from functools import partial
    get_completion_partial = partial(get_completion, temperature=temperature, max_tokens=max_tokens)
    with multiprocessing.Pool(processes=num_cpus) as pool:
        results = pool.map(get_completion_partial, dialogs)
    total_cost = sum([cost for _, cost in results])
    return [response for response, _ in results], total_cost

def get_completion(dialogs, temperature=0, max_tokens=100):
    from transformers import AutoModelForCausalLM, AutoTokenizer
    import torch
    import time
    
    # 直接使用本地模型路径，避免联网
    model_path = "/mnt/data/huggingface_cache/models--Qwen--Qwen2-7B-Instruct/snapshots/f2826a00ceef68f0f2b946d945ecc0477ce4450c"
    
    global _qwen_model, _qwen_tokenizer
    if '_qwen_model' not in globals():
        _qwen_tokenizer = AutoTokenizer.from_pretrained(
            model_path, 
            trust_remote_code=True,
            local_files_only=True  # 强制只使用本地文件
        )
        _qwen_model = AutoModelForCausalLM.from_pretrained(
            model_path,
            torch_dtype=torch.float16,
            device_map="auto",
            trust_remote_code=True,
            local_files_only=True  # 强制只使用本地文件
        )
        _qwen_model.eval()
    
    max_retries = 20
    for i in range(max_retries):
        try:
            with torch.no_grad():
                text = _qwen_tokenizer.apply_chat_template(
                    dialogs,
                    tokenize=False,
                    add_generation_prompt=True
                )
                
                model_inputs = _qwen_tokenizer([text], return_tensors="pt").to(_qwen_model.device)
                
                # 根据temperature决定采样策略
                if temperature == 0:
                    # temperature=0 时使用贪婪解码（确定性输出）
                    generated_ids = _qwen_model.generate(
                        **model_inputs,
                        max_new_tokens=max_tokens,
                        do_sample=False  # 关闭采样，使用贪婪解码
                    )
                else:
                    # temperature>0 时使用采样
                    generated_ids = _qwen_model.generate(
                        **model_inputs,
                        max_new_tokens=max_tokens,
                        temperature=temperature,
                        do_sample=True
                    )
                
                generated_ids = [
                    output_ids[len(input_ids):] for input_ids, output_ids in zip(model_inputs.input_ids, generated_ids)
                ]
                
                response = _qwen_tokenizer.batch_decode(generated_ids, skip_special_tokens=True)[0]
                
                prompt_tokens = len(model_inputs.input_ids[0])
                completion_tokens = len(generated_ids[0])
                this_cost = 0
                
                return response, this_cost
            
        except Exception as e:
            if i < max_retries - 1:
                time.sleep(6)
            else:
                print(f"An error of type {type(e).__name__} occurred: {e}")
                return "Error", 0

def format_numbers(numbers):
    return '[' + ', '.join('{:.2f}'.format(num) for num in numbers) + ']'

def format_percentages(numbers):
    return '[' + ', '.join('{:.2%}'.format(num) for num in numbers) + ']'
