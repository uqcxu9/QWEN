# QWEN

经济智能体模拟项目，使用 QWEN 模型进行决策。

## 环境配置

### 1. 创建 Conda 环境
```bash
conda create -n econagent python=3.10 -y
conda activate econagent
```

### 2. 安装依赖
```bash
pip install -r requirements.txt
```

### 3. 配置 HuggingFace 缓存路径
```bash
export HF_HOME=/mnt/data/huggingface_cache
```

或者将以下内容添加到 `~/.bashrc`：
```bash
echo 'export HF_HOME=/mnt/data/huggingface_cache' >> ~/.bashrc
source ~/.bashrc
```

### 4. 下载 QWEN 模型
确保已下载 Qwen2-7B-Instruct 模型到本地缓存目录。

## 运行

```bash
python simulate.py --policy_model gpt --num_agents 3 --episode_length 3
```

## 模型配置

模型路径配置在 `simulate_utils.py` 中，请根据实际模型存储位置修改：
```python
model_path = "/mnt/data/huggingface_cache/models--Qwen--Qwen2-7B-Instruct/snapshots/..."
```

## 注意事项

- 使用 `local_files_only=True` 参数以离线模式加载模型
- 需要 GPU 环境运行大模型
- 确保有足够的磁盘空间存储模型文件（约15GB）
